using System;

public enum MessageType {
    Error,
    Warning,
    Information
}

public enum MessageBlockCss {
    b230,
    b470,
    b710
}
