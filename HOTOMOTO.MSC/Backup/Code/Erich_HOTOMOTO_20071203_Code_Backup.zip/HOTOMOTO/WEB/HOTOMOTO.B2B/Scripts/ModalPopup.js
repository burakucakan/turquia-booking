﻿// JScript File

function ModalOK() 
{
//    theForm.disabled=false;
    $get('dvDeActive').style.display = 'none'; 
}

function ModalCancel() 
{
//    theForm.disabled=false;
    $get('dvDeActive').style.display = 'none'; 
}

function DeActive() {
//    theForm.disabled=true;
    $get('dvDeActive').style.display = 'block'; 
}